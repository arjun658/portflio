#include "stdafx.h"
#include "GenericGamestate.h"

GenericGamestate::~GenericGamestate()
{
    // do nothing
}

void GenericGamestate::OnGamestateEnter()
{
    // do nothing
}

void GenericGamestate::OnGamestateLeave()
{
    // do nothing
}

void GenericGamestate::OnGamestateFrame()
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(KeyInputEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(MouseButtonInputEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(MouseMovedInputEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(MouseScrollInputEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(KeyCharEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEvent(GamepadInputEvent& inputEvent)
{
    // do nothing
}

void GenericGamestate::OnGamestateInputEventLost()
{
    // do nothing
}

void GenericGamestate::OnGamestateBroadcastEvent(const BroadcastEvent& broadcastEvent)
{
    // do nothing
}
