#include "stdafx.h"
#include "MainMenuGamestate.h"

void MainMenuGamestate::OnGamestateEnter()
{
}

void MainMenuGamestate::OnGamestateLeave()
{
}

void MainMenuGamestate::OnGamestateFrame()
{
}

void MainMenuGamestate::OnGamestateInputEvent(KeyInputEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEvent(MouseButtonInputEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEvent(MouseMovedInputEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEvent(MouseScrollInputEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEvent(KeyCharEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEvent(GamepadInputEvent& inputEvent)
{
}

void MainMenuGamestate::OnGamestateInputEventLost()
{
}